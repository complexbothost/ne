import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Paste, PasteVersion } from "@shared/schema";
import PageLayout from "@/components/layout/page-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, User, Calendar, History, RotateCcw } from "lucide-react";
import { format } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { PasteVersionHistory } from "@/components/paste-version-history";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function PastePage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<PasteVersion | null>(null);

  const {
    data: paste,
    isLoading,
    error
  } = useQuery<Paste>({
    queryKey: [`/api/pastes/${id}`],
  });

  // Restore version mutation
  const restoreVersionMutation = useMutation({
    mutationFn: async (version: PasteVersion) => {
      await apiRequest("POST", `/api/pastes/${id}/restore`, {
        versionId: version.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/pastes/${id}`] });
      toast({
        title: "Version restored",
        description: "The paste has been restored to the selected version.",
      });
      setSelectedVersion(null);
      setShowVersionHistory(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to restore version",
        variant: "destructive",
      });
    },
  });

  const handleViewRaw = () => {
    window.open(`/api/pastes/${id}/raw`, '_blank');
  };

  const handleVersionSelect = (version: PasteVersion) => {
    setSelectedVersion(version);
  };

  if (isLoading) {
    return (
      <PageLayout>
        <div className="container max-w-7xl mx-auto py-8">
          <Card className="w-full h-[600px] border-white/10 bg-black animate-pulse">
            <CardContent className="p-6">
              <div className="h-6 w-48 bg-white/5 rounded mb-4"></div>
              <div className="space-y-2">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="h-4 bg-white/5 rounded w-full"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageLayout>
    );
  }

  if (error || !paste) {
    return (
      <PageLayout>
        <div className="container max-w-7xl mx-auto py-8">
          <Card className="border-white/10 bg-black">
            <CardContent className="p-6">
              <div className="text-center py-8 text-red-400">
                {error ? "Error loading paste" : "Paste not found"}
              </div>
            </CardContent>
          </Card>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container max-w-7xl mx-auto py-8 px-4">
        <Card className="border-white/10 bg-black">
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <FileText className="h-5 w-5 text-purple-400" />
                {selectedVersion ? selectedVersion.title : paste.title}
              </CardTitle>
              <div className="flex items-center gap-2">
                <Sheet open={showVersionHistory} onOpenChange={setShowVersionHistory}>
                  <SheetTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-white/10 text-white/70 hover:bg-white/5"
                    >
                      <History className="h-4 w-4 mr-2" />
                      History
                    </Button>
                  </SheetTrigger>
                  <SheetContent>
                    <SheetHeader>
                      <SheetTitle>Version History</SheetTitle>
                    </SheetHeader>
                    <PasteVersionHistory
                      pasteId={parseInt(id)}
                      onVersionSelect={handleVersionSelect}
                      onClose={() => setShowVersionHistory(false)}
                    />
                  </SheetContent>
                </Sheet>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleViewRaw}
                  className="border-white/10 text-white/70 hover:bg-white/5"
                >
                  <Download className="h-4 w-4 mr-2" />
                  View Raw
                </Button>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-white/50">
              <div className="flex items-center gap-1">
                <User className="h-4 w-4" />
                <span>User #{paste.userId}</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                <span>{format(new Date(paste.createdAt), "MMM d, yyyy")}</span>
              </div>
            </div>
            {selectedVersion && (
              <div className="flex items-center justify-between mt-4 p-2 rounded bg-purple-500/10 border border-purple-500/20">
                <CardDescription className="text-purple-400">
                  Viewing version from {format(new Date(selectedVersion.createdAt), "MMM d, yyyy HH:mm")}
                  {selectedVersion.message && ` - ${selectedVersion.message}`}
                </CardDescription>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => restoreVersionMutation.mutate(selectedVersion)}
                  disabled={restoreVersionMutation.isPending}
                  className="border-purple-500/20 hover:border-purple-500/40 hover:bg-purple-500/20"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restore Version
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px] w-full rounded-md border border-white/10">
              <pre className="p-4 font-mono text-sm text-white/90 whitespace-pre-wrap">
                {selectedVersion ? selectedVersion.content : paste.content}
              </pre>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}