
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useParams, useNavigate } from "react-router-dom";
import PageLayout from "@/components/layout/page-layout";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { FollowButton } from "@/components/follow-button";
import { Separator } from "@/components/ui/separator";
import { UserPlus, UserCheck, User as UserIcon, ArrowLeft } from "lucide-react";
import axios from "axios";
import { getInitials } from "@/lib/utils";

interface User {
  id: number;
  username: string;
  bio: string;
  avatarUrl: string | null;
  role: string | null;
  isFollowing?: boolean;
}

export default function FollowingPage() {
  const { user } = useAuth();
  const { userId, tab = "following" } = useParams<{ userId: string; tab?: string }>();
  const navigate = useNavigate();
  const [followers, setFollowers] = useState<User[]>([]);
  const [following, setFollowing] = useState<User[]>([]);
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        if (!userId) return;

        // Fetch user profile
        const profileResponse = await axios.get(`/api/users/${userId}`);
        setProfileUser(profileResponse.data);

        // Fetch followers
        const followersResponse = await axios.get(`/api/users/${userId}/followers`);
        setFollowers(followersResponse.data);

        // Fetch following
        const followingResponse = await axios.get(`/api/users/${userId}/following`);
        setFollowing(followingResponse.data);
      } catch (error) {
        console.error("Error fetching follow data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [userId]);

  const handleFollowChange = async (targetUserId: number, isFollowing: boolean, listType: "followers" | "following") => {
    if (listType === "followers") {
      setFollowers(prev => 
        prev.map(follower => 
          follower.id === targetUserId 
            ? { ...follower, isFollowing } 
            : follower
        )
      );
    } else {
      setFollowing(prev => 
        prev.map(followedUser => 
          followedUser.id === targetUserId 
            ? { ...followedUser, isFollowing } 
            : followedUser
        )
      );
    }
  };

  if (!profileUser && !isLoading) {
    return (
      <PageLayout>
        <div className="container mx-auto py-8">
          <div className="text-center py-12">
            <p className="text-muted-foreground">User not found</p>
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate(`/user/${userId}`)}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Profile
          </Button>
          
          {profileUser && (
            <div className="flex items-center gap-4">
              <Avatar className="h-12 w-12">
                <AvatarImage src={profileUser.avatarUrl || undefined} alt={profileUser.username} />
                <AvatarFallback>{getInitials(profileUser.username)}</AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold">{profileUser.username}</h1>
                <p className="text-muted-foreground">
                  {tab === "followers" ? "People following" : "People followed by"} {profileUser.username}
                </p>
              </div>
            </div>
          )}
        </div>

        <Tabs defaultValue={tab} onValueChange={(value) => navigate(`/user/${userId}/follows/${value}`)}>
          <TabsList className="grid grid-cols-2 mb-8">
            <TabsTrigger value="followers" className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Followers
              <span className="bg-primary/20 text-primary rounded-full px-2 py-0.5 text-xs ml-1">
                {followers.length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="following" className="flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              Following
              <span className="bg-primary/20 text-primary rounded-full px-2 py-0.5 text-xs ml-1">
                {following.length}
              </span>
            </TabsTrigger>
          </TabsList>

          <Card>
            <CardContent className="p-6">
              <TabsContent value="followers" className="mt-0">
                {isLoading ? (
                  <div className="flex justify-center py-12">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                  </div>
                ) : followers.length > 0 ? (
                  <div className="space-y-4">
                    {followers.map((follower, index) => (
                      <div key={follower.id}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10 cursor-pointer" onClick={() => navigate(`/user/${follower.id}`)}>
                              <AvatarImage src={follower.avatarUrl || undefined} alt={follower.username} />
                              <AvatarFallback>{getInitials(follower.username)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium cursor-pointer hover:underline" onClick={() => navigate(`/user/${follower.id}`)}>
                                {follower.username}
                              </p>
                              {follower.bio && (
                                <p className="text-sm text-muted-foreground truncate max-w-xs">
                                  {follower.bio.substring(0, 50)}{follower.bio.length > 50 ? '...' : ''}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          {user && user.id !== follower.id && (
                            <FollowButton 
                              userId={follower.id}
                              initialIsFollowing={follower.isFollowing || false}
                              onFollowChange={(isFollowing) => handleFollowChange(follower.id, isFollowing, "followers")}
                            />
                          )}
                        </div>
                        {index < followers.length - 1 && <Separator className="my-4" />}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <UserIcon className="h-12 w-12 mx-auto text-muted-foreground opacity-20 mb-4" />
                    <p className="text-muted-foreground">No followers yet</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="following" className="mt-0">
                {isLoading ? (
                  <div className="flex justify-center py-12">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                  </div>
                ) : following.length > 0 ? (
                  <div className="space-y-4">
                    {following.map((followedUser, index) => (
                      <div key={followedUser.id}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10 cursor-pointer" onClick={() => navigate(`/user/${followedUser.id}`)}>
                              <AvatarImage src={followedUser.avatarUrl || undefined} alt={followedUser.username} />
                              <AvatarFallback>{getInitials(followedUser.username)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium cursor-pointer hover:underline" onClick={() => navigate(`/user/${followedUser.id}`)}>
                                {followedUser.username}
                              </p>
                              {followedUser.bio && (
                                <p className="text-sm text-muted-foreground truncate max-w-xs">
                                  {followedUser.bio.substring(0, 50)}{followedUser.bio.length > 50 ? '...' : ''}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          {user && user.id !== followedUser.id && (
                            <FollowButton 
                              userId={followedUser.id}
                              initialIsFollowing={true}
                              onFollowChange={(isFollowing) => handleFollowChange(followedUser.id, isFollowing, "following")}
                            />
                          )}
                        </div>
                        {index < following.length - 1 && <Separator className="my-4" />}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <UserCheck className="h-12 w-12 mx-auto text-muted-foreground opacity-20 mb-4" />
                    <p className="text-muted-foreground">Not following anyone yet</p>
                  </div>
                )}
              </TabsContent>
            </CardContent>
          </Card>
        </Tabs>
      </div>
    </PageLayout>
  );
}
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PageLayout from "@/components/layout/page-layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { User } from "@/lib/types";
import axios from "axios";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { FollowButton } from "@/components/follow-button";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "react-router-dom";
import { RoleUsername } from "@/components/role-username";

export default function FollowingPage() {
  const { userId, tab = "followers" } = useParams();
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [followers, setFollowers] = useState<User[]>([]);
  const [following, setFollowing] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      if (!userId) return;
      
      try {
        const response = await axios.get(`/api/users/${userId}`);
        setUser(response.data);
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };

    const fetchFollowData = async () => {
      if (!userId) return;
      
      setLoading(true);
      try {
        const [followersRes, followingRes] = await Promise.all([
          axios.get(`/api/users/${userId}/followers`),
          axios.get(`/api/users/${userId}/following`)
        ]);
        
        setFollowers(followersRes.data);
        setFollowing(followingRes.data);
      } catch (error) {
        console.error("Error fetching follow data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
    fetchFollowData();
  }, [userId]);

  const handleTabChange = (value: string) => {
    navigate(`/user/${userId}/follows/${value}`);
  };

  if (!user) {
    return (
      <PageLayout>
        <div className="container mx-auto py-8">
          <div className="flex flex-col gap-6">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-[500px] w-full" />
          </div>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      <div className="container mx-auto py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">
            <Link to={`/user/${user.id}`} className="hover:underline">
              {user.username}
            </Link>
            's Connections
          </h1>
        </div>

        <Card className="overflow-hidden">
          <Tabs 
            defaultValue={tab} 
            onValueChange={handleTabChange}
            className="w-full"
          >
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="followers">
                Followers ({followers.length})
              </TabsTrigger>
              <TabsTrigger value="following">
                Following ({following.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="followers" className="p-6">
              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : followers.length > 0 ? (
                <div className="divide-y">
                  {followers.map((follower) => (
                    <div key={follower.id} className="flex items-center justify-between py-3">
                      <Link to={`/user/${follower.id}`} className="flex items-center gap-3 hover:underline">
                        <Avatar className="h-10 w-10">
                          <AvatarImage
                            src={follower.avatarUrl || ""}
                            alt={follower.username}
                          />
                          <AvatarFallback>
                            {follower.username.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <RoleUsername user={follower} />
                      </Link>
                      
                      {currentUser && currentUser.id !== follower.id && (
                        <FollowButton userId={follower.id} size="xs" />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No followers yet
                </div>
              )}
            </TabsContent>

            <TabsContent value="following" className="p-6">
              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : following.length > 0 ? (
                <div className="divide-y">
                  {following.map((followed) => (
                    <div key={followed.id} className="flex items-center justify-between py-3">
                      <Link to={`/user/${followed.id}`} className="flex items-center gap-3 hover:underline">
                        <Avatar className="h-10 w-10">
                          <AvatarImage
                            src={followed.avatarUrl || ""}
                            alt={followed.username}
                          />
                          <AvatarFallback>
                            {followed.username.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <RoleUsername user={followed} />
                      </Link>
                      
                      {currentUser && currentUser.id !== followed.id && (
                        <FollowButton userId={followed.id} size="xs" />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Not following anyone yet
                </div>
              )}
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </PageLayout>
  );
}
