import { useState } from "react";
import { useTheme } from "@/hooks/use-theme";
import PageLayout from "@/components/layout/page-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Palette, Keyboard, Layout } from "lucide-react";

const DEFAULT_SHORTCUTS = {
  newPaste: "mod+n",
  save: "mod+s",
  find: "mod+f",
  commandPalette: "mod+k",
  switchTheme: "mod+shift+t",
};

export default function WorkspaceSettings() {
  const { theme, setTheme } = useTheme();
  const [shortcuts, setShortcuts] = useState(DEFAULT_SHORTCUTS);
  const [multipleWindows, setMultipleWindows] = useState(false);
  const [customTheme, setCustomTheme] = useState({
    primary: "#7c3aed",
    background: "#000000",
    text: "#ffffff",
    accent: "#4f46e5",
  });

  const handleShortcutChange = (action: string, value: string) => {
    setShortcuts(prev => ({
      ...prev,
      [action]: value,
    }));
  };

  const handleThemeChange = (property: string, value: string) => {
    setCustomTheme(prev => ({
      ...prev,
      [property]: value,
    }));
  };

  return (
    <PageLayout>
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Workspace Settings</h1>
        
        <Tabs defaultValue="theme" className="space-y-6">
          <TabsList className="bg-black border border-white/10">
            <TabsTrigger value="theme" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Theme
            </TabsTrigger>
            <TabsTrigger value="shortcuts" className="flex items-center gap-2">
              <Keyboard className="h-4 w-4" />
              Shortcuts
            </TabsTrigger>
            <TabsTrigger value="layout" className="flex items-center gap-2">
              <Layout className="h-4 w-4" />
              Layout
            </TabsTrigger>
          </TabsList>

          <TabsContent value="theme">
            <Card className="border-white/10 bg-black">
              <CardHeader>
                <CardTitle>Theme Customization</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label>Primary Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={customTheme.primary}
                        onChange={(e) => handleThemeChange("primary", e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={customTheme.primary}
                        onChange={(e) => handleThemeChange("primary", e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Background Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={customTheme.background}
                        onChange={(e) => handleThemeChange("background", e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={customTheme.background}
                        onChange={(e) => handleThemeChange("background", e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Text Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={customTheme.text}
                        onChange={(e) => handleThemeChange("text", e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={customTheme.text}
                        onChange={(e) => handleThemeChange("text", e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Accent Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={customTheme.accent}
                        onChange={(e) => handleThemeChange("accent", e.target.value)}
                        className="w-16 h-10 p-1"
                      />
                      <Input
                        type="text"
                        value={customTheme.accent}
                        onChange={(e) => handleThemeChange("accent", e.target.value)}
                        className="flex-1"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button>Apply Theme</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shortcuts">
            <Card className="border-white/10 bg-black">
              <CardHeader>
                <CardTitle>Keyboard Shortcuts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label>New Paste</Label>
                    <Input
                      value={shortcuts.newPaste}
                      onChange={(e) => handleShortcutChange("newPaste", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Save Paste</Label>
                    <Input
                      value={shortcuts.save}
                      onChange={(e) => handleShortcutChange("save", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Find in Paste</Label>
                    <Input
                      value={shortcuts.find}
                      onChange={(e) => handleShortcutChange("find", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Command Palette</Label>
                    <Input
                      value={shortcuts.commandPalette}
                      onChange={(e) => handleShortcutChange("commandPalette", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Switch Theme</Label>
                    <Input
                      value={shortcuts.switchTheme}
                      onChange={(e) => handleShortcutChange("switchTheme", e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline">Reset to Defaults</Button>
                  <Button>Save Shortcuts</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="layout">
            <Card className="border-white/10 bg-black">
              <CardHeader>
                <CardTitle>Layout Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between space-x-2">
                  <div className="space-y-0.5">
                    <Label>Multiple Paste Windows</Label>
                    <p className="text-sm text-muted-foreground">
                      Enable support for multiple paste windows
                    </p>
                  </div>
                  <Switch
                    checked={multipleWindows}
                    onCheckedChange={setMultipleWindows}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
}
