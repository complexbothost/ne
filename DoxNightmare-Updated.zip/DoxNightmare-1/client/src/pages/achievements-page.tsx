
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import PageLayout from "@/components/layout/page-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { AchievementBadge } from "@/components/achievement-badge";
import { Separator } from "@/components/ui/separator";
import { Shield, Award } from "lucide-react";
import axios from "axios";
import { AchievementType } from "@shared/schema";

interface Achievement {
  id: number;
  userId: number;
  achievementType: AchievementType;
  earnedAt: string;
  seen: boolean;
}

export default function AchievementsPage() {
  const { user } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        if (user) {
          const response = await axios.get(`/api/users/${user.id}/achievements`);
          setAchievements(response.data);
        }
      } catch (error) {
        console.error("Error fetching achievements:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAchievements();
  }, [user]);

  const markAllAsSeen = async () => {
    try {
      if (user) {
        await axios.post(`/api/users/${user.id}/achievements/mark-seen`);
        setAchievements(prev => prev.map(a => ({ ...a, seen: true })));
      }
    } catch (error) {
      console.error("Error marking achievements as seen:", error);
    }
  };

  useEffect(() => {
    // Mark as seen when the page is visited
    if (achievements.some(a => !a.seen)) {
      markAllAsSeen();
    }
  }, [achievements]);

  // Group achievements by type to avoid duplicates in display
  const uniqueAchievements = Array.from(
    new Set(achievements.map(a => a.achievementType))
  ).map(type => {
    const achievement = achievements.find(a => a.achievementType === type);
    return achievement;
  }).filter(Boolean) as Achievement[];

  return (
    <PageLayout>
      <div className="container mx-auto py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Achievements</h1>
          <p className="text-muted-foreground">
            Track your progress and earn badges for your contributions
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card className="mb-6">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-primary" />
                    <span>Your Achievements</span>
                  </CardTitle>
                  <span className="text-sm text-muted-foreground">
                    {uniqueAchievements.length} earned
                  </span>
                </div>
                <CardDescription>
                  Badges you've earned through your activity on the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                  </div>
                ) : uniqueAchievements.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {uniqueAchievements.map((achievement) => (
                      <div key={achievement.id} className="p-4 bg-background/60 rounded-lg border flex flex-col items-center text-center gap-2">
                        <AchievementBadge 
                          type={achievement.achievementType} 
                          size="lg" 
                        />
                        <div>
                          <p className="font-medium">
                            {achievement.achievementType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(achievement.earnedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">
                      You haven't earned any achievements yet. Start creating pastes and
                      interacting with the community!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  <span>Achievement Guide</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="available">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="available">Available</TabsTrigger>
                    <TabsTrigger value="howto">How to Earn</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="available" className="space-y-4">
                    <div className="flex items-center gap-3">
                      <AchievementBadge type="first_paste" withTooltip={false} />
                      <div>
                        <p className="font-medium">First Paste</p>
                        <p className="text-xs text-muted-foreground">Create your first paste</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center gap-3">
                      <AchievementBadge type="popular_paste" withTooltip={false} />
                      <div>
                        <p className="font-medium">Popular Content</p>
                        <p className="text-xs text-muted-foreground">Create content with high visibility</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center gap-3">
                      <AchievementBadge type="contributor" withTooltip={false} />
                      <div>
                        <p className="font-medium">Contributor</p>
                        <p className="text-xs text-muted-foreground">Create 10+ pastes</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center gap-3">
                      <AchievementBadge type="community_member" withTooltip={false} />
                      <div>
                        <p className="font-medium">Community Member</p>
                        <p className="text-xs text-muted-foreground">Leave 5+ comments</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="flex items-center gap-3">
                      <AchievementBadge type="profile_complete" withTooltip={false} />
                      <div>
                        <p className="font-medium">Profile Complete</p>
                        <p className="text-xs text-muted-foreground">Complete your profile</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="howto">
                    <div className="space-y-4">
                      <p className="text-sm">
                        Achievements are earned automatically as you interact with the platform:
                      </p>
                      <ul className="space-y-2 list-disc list-inside text-sm text-muted-foreground">
                        <li>Create pastes and receive achievements for being active</li>
                        <li>Interact with other users through comments</li>
                        <li>Complete your profile with bio and avatar</li>
                        <li>Earn special roles from the shop</li>
                      </ul>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}
