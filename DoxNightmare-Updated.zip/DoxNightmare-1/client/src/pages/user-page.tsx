import { useParams, Link } from "react-router-dom";
import { FollowButton } from "@/components/follow-button";
import { useState, useEffect } from 'react';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

function UserProfilePage() {
  const { userId } = useParams();
  const [userData, setUserData] = useState<any>(null);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch(`/api/users/${userId}`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setUserData(data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    const fetchCurrentUser = async () => {
      try {
        const response = await fetch('/api/user');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setUser(data);
      } catch (error) {
        console.error('Error fetching current user data:', error);
      }
    };

    fetchUserData();
    fetchCurrentUser();
  }, [userId]);

  if (!userData) {
    return <p>Loading...</p>;
  }

  return (
    <div className="container mx-auto p-8">
      <div className="flex items-center gap-4 mb-3">
        <Avatar className="h-24 w-24">
          <AvatarImage src={userData?.avatarUrl} alt={userData?.username} />
          <AvatarFallback>{userData?.username?.[0]?.toUpperCase()}</AvatarFallback>
        </Avatar>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{userData?.username}</h1>
            {user && user.id !== userData?.id && (
              <FollowButton 
                userId={userData?.id} 
                initialIsFollowing={userData?.isFollowing}
              />
            )}
          </div>
          <div className="flex items-center mt-1 space-x-4">
            <p className="text-muted-foreground">Member since {userData ? new Date(userData.createdAt).toLocaleDateString() : ""}</p>
            <div className="flex items-center space-x-3">
              <Link to={`/user/${userData?.id}/follows/followers`} className="text-sm hover:underline">
                <span className="font-semibold">{userData?.followersCount}</span> followers
              </Link>
              <Link to={`/user/${userData?.id}/follows/following`} className="text-sm hover:underline">
                <span className="font-semibold">{userData?.followingCount}</span> following
              </Link>
            </div>
          </div>
        </div>
      </div>
      {/* rest of the user profile content */}
    </div>
  );
}

export default UserProfilePage;