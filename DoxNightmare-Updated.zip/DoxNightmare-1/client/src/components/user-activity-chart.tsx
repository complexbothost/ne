
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export function UserActivityChart({ userId, className = "" }: { userId: number, className?: string }) {
  const [activityData, setActivityData] = useState<{ name: string; pastes: number }[]>([]);
  
  useEffect(() => {
    // For demo purposes, generate random activity data
    // In production, this would come from an API call
    const generateRandomData = () => {
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      return days.map(day => ({
        name: day,
        pastes: Math.floor(Math.random() * 10)
      }));
    };
    
    setActivityData(generateRandomData());
  }, [userId]);
  
  return (
    <Card className={`border-zinc-800 bg-zinc-900/60 backdrop-blur-sm ${className}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={activityData}>
              <XAxis 
                dataKey="name" 
                stroke="#6b7280" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false} 
              />
              <YAxis 
                stroke="#6b7280" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false} 
                tickFormatter={(value) => `${value}`} 
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#18181b",
                  borderColor: "#3f3f46",
                  borderRadius: "6px",
                }}
                labelStyle={{ color: "#fff" }}
                itemStyle={{ color: "#a78bfa" }}
              />
              <Bar 
                dataKey="pastes" 
                fill="hsl(var(--purple-600))" 
                radius={[4, 4, 0, 0]} 
                barSize={30} 
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
