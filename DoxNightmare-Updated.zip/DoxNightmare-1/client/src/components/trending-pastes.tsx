
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Link } from "react-router-dom";
import { Badge } from "./ui/badge";
import { Flame, Clock, Star } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Paste {
  id: number;
  title: string;
  content: string;
  userId: number;
  username: string;
  createdAt: string;
  isPrivate: boolean;
  isAdminPaste: boolean;
  isPinned: boolean;
  views: number;
}

export function TrendingPastes() {
  const [trendingPastes, setTrendingPastes] = useState<Paste[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    async function fetchTrendingPastes() {
      try {
        const response = await fetch("/api/pastes");
        const data = await response.json();
        // Sort by views for trending
        const trending = [...data].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 5);
        setTrendingPastes(trending);
      } catch (error) {
        console.error("Error fetching trending pastes:", error);
      } finally {
        setLoading(false);
      }
    }
    
    fetchTrendingPastes();
  }, []);
  
  return (
    <Card className="border-zinc-800 bg-zinc-900/60 backdrop-blur-sm">
      <CardHeader className="border-b border-zinc-800 px-5 py-4">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <Flame className="h-4 w-4 text-orange-500" />
          Trending Pastes
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue="today" className="w-full">
          <div className="p-2 border-b border-zinc-800">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="today">Today</TabsTrigger>
              <TabsTrigger value="week">This Week</TabsTrigger>
              <TabsTrigger value="month">This Month</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="today" className="p-0 pt-2">
            {loading ? (
              <div className="flex justify-center p-4">Loading trending pastes...</div>
            ) : (
              <div className="divide-y divide-zinc-800">
                {trendingPastes.map((paste) => (
                  <Link 
                    to={`/paste/${paste.id}`} 
                    key={paste.id}
                    className="block p-4 hover:bg-zinc-800/50 transition"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-white truncate">{paste.title}</h3>
                        <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatDistanceToNow(new Date(paste.createdAt), { addSuffix: true })}
                          </span>
                          <span className="flex items-center gap-1">
                            <Star className="h-3 w-3" />
                            {paste.views || 0} views
                          </span>
                        </div>
                      </div>
                      {paste.isPinned && (
                        <Badge className="bg-amber-600 text-white">Pinned</Badge>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="week" className="p-4">
            <div className="text-center text-zinc-400">
              Weekly trending data will be available soon
            </div>
          </TabsContent>
          
          <TabsContent value="month" className="p-4">
            <div className="text-center text-zinc-400">
              Monthly trending data will be available soon
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
