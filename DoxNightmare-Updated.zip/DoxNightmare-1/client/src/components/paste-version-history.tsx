import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PasteVersion } from "@shared/schema";
import { format } from "date-fns";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { History, Clock, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface PasteVersionHistoryProps {
  pasteId: number;
  onVersionSelect: (version: PasteVersion) => void;
  onClose: () => void;
}

export function PasteVersionHistory({ pasteId, onVersionSelect, onClose }: PasteVersionHistoryProps) {
  const { data: versions, isLoading } = useQuery<PasteVersion[]>({
    queryKey: [`/api/pastes/${pasteId}/versions`],
    queryFn: async () => {
      const response = await apiRequest("GET", `/api/pastes/${pasteId}/versions`);
      return response.json();
    },
  });

  if (isLoading) {
    return <div className="p-4 text-center">Loading version history...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <History className="h-5 w-5" />
          Version History
        </h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </div>

      <ScrollArea className="h-[400px] pr-4">
        <div className="space-y-2">
          {versions?.map((version) => (
            <div
              key={version.id}
              className="p-3 rounded-lg border border-white/10 hover:bg-white/5 cursor-pointer transition-colors"
              onClick={() => onVersionSelect(version)}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{version.title}</span>
                <span className="text-sm text-zinc-400 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {format(new Date(version.createdAt), "MMM d, yyyy HH:mm")}
                </span>
              </div>
              {version.message && (
                <p className="text-sm text-zinc-400">{version.message}</p>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
