import { useEffect, useState } from "react";
import { User, UserRole } from "@shared/schema";
import { cn } from "@/lib/utils";

interface RoleUsernameProps {
  user: Pick<User, "username" | "role">;
  className?: string;
  onClick?: () => void;
}

export default function RoleUsername({ user, className, onClick }: RoleUsernameProps) {
  const [glitchActive, setGlitchActive] = useState(false);

  useEffect(() => {
    if (user.role === UserRole.GANG) {
      const interval = setInterval(() => {
        setGlitchActive(true);
        setTimeout(() => setGlitchActive(false), 100);
      }, 1200);

      return () => clearInterval(interval);
    }
  }, [user.role]);

  if (!user.role) {
    return (
      <span 
        className={cn("cursor-pointer", className)}
        onClick={onClick}
      >
        {user.username}
      </span>
    );
  }

  switch (user.role) {
    case UserRole.RICH:
      return (
        <div 
          className={cn(
            "cursor-pointer relative",
            "rich-container",
            "p-2 rounded",
            className
          )}
          onClick={onClick}
        >
          <div className="particles" style={{ height: "200%" }}>
            {[...Array(8)].map((_, i) => (
              <div key={i} className="rich-particle" />
            ))}
          </div>
          <span className="sparkle-text relative z-10">
            {user.username}
          </span>
          <style jsx>{`
            .rich-container {
              background: transparent;
              overflow: hidden;
            }
            .sparkle-text {
              background-image: linear-gradient(45deg, #ff1b6b, #45caff);
              background-size: 200% 200%;
              -webkit-background-clip: text;
              -webkit-text-fill-color: transparent;
              animation: sparkle 3s ease-in-out infinite;
            }
            .rich-particle {
              position: absolute;
              width: 3px;
              height: 3px;
              background: gold;
              opacity: 0.7;
              animation: fall 4s linear infinite;
            }
            @keyframes fall {
              0% {
                transform: translateY(-100%);
                opacity: 0.7;
              }
              100% {
                transform: translateY(100%);
                opacity: 0;
              }
            }
            @keyframes sparkle {
              0% { background-position: 0% 50%; }
              50% { background-position: 100% 50%; }
              100% { background-position: 0% 50%; }
            }
          `}</style>
        </div>
      );

    case UserRole.FRAUD:
      return (
        <span 
          className={cn(
            "cursor-pointer",
            "role-fraud",
            "animate-pulse",
            className
          )}
          onClick={onClick}
        >
          {user.username}
        </span>
      );

    case UserRole.GANG:
      return (
        <span 
          className={cn(
            "cursor-pointer",
            "role-gang",
            glitchActive && "glitch-active",
            className
          )}
          onClick={onClick}
        >
          {user.username}
        </span>
      );

    default:
      return (
        <span 
          className={cn("cursor-pointer", className)}
          onClick={onClick}
        >
          {user.username}
        </span>
      );
  }
}