import { BellRing, FileText, LayoutDashboard, ScrollText, Shield, ShieldAlert, User, Users } from 'lucide-react';
import { Link, NavLink, Outlet } from "react-router-dom";
import { cn } from '@/lib/utils';

const linkClasses = (href: string) => ({
  isActive: "bg-sky-100 text-sky-700 font-bold",
  base: "flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-sky-700"
})

export default function AdminLayout({ children }: { children?: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="flex flex-col md:flex-row min-h-screen">
        {/* Sidebar */}
        <div className="w-full md:w-64 bg-white shadow-md p-4 md:min-h-screen">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-xl font-bold text-gray-800">Admin Panel</h1>
            <Link to="/" className="text-sm text-gray-600 hover:text-sky-700 md:hidden">
              Back to Site
            </Link>
          </div>

          {/* Navigation links */}
          <div className="space-y-2">
            <NavLink 
              to="/admin" 
              end
              className={({ isActive }) => 
                cn(linkClasses('/admin').base, isActive && linkClasses('/admin').isActive)
              }
            >
              <LayoutDashboard className="mr-2 h-4 w-4" />
              Dashboard
            </NavLink>

            <NavLink 
              to="/admin/users"
              className={({ isActive }) => 
                cn(linkClasses('/admin/users').base, isActive && linkClasses('/admin/users').isActive)
              }
            >
              <Users className="mr-2 h-4 w-4" />
              Users
            </NavLink>

            <NavLink 
              to="/admin/pastes"
              className={({ isActive }) => 
                cn(linkClasses('/admin/pastes').base, isActive && linkClasses('/admin/pastes').isActive)
              }
            >
              <FileText className="mr-2 h-4 w-4" />
              Pastes
            </NavLink>

            <NavLink 
              to="/admin/ip-restrictions"
              className={({ isActive }) => 
                cn(linkClasses('/admin/ip-restrictions').base, isActive && linkClasses('/admin/ip-restrictions').isActive)
              }
            >
              <ShieldAlert className="mr-2 h-4 w-4" />
              IP Restrictions
            </NavLink>

            <NavLink 
              to="/admin/audit-logs"
              className={({ isActive }) => 
                cn(linkClasses('/admin/audit-logs').base, isActive && linkClasses('/admin/audit-logs').isActive)
              }
            >
              <ScrollText className="mr-2 h-4 w-4" />
              Audit Logs
            </NavLink>

            <NavLink 
              to="/admin/announcements"
              className={({ isActive }) => 
                cn(linkClasses('/admin/announcements').base, isActive && linkClasses('/admin/announcements').isActive)
              }
            >
              <BellRing className="mr-2 h-4 w-4" />
              Announcements
            </NavLink>

            <div className="pt-4 mt-4 border-t border-gray-200">
              <Link to="/" className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-sky-700">
                Back to Site
              </Link>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 p-6">
          {children || <Outlet />}
        </div>
      </div>
    </div>
  );
}