
import { useState, useEffect } from "react";
import { Check, Copy, Download, Share2 } from "lucide-react";
import { Button } from "./ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import Prism from "prismjs";
import "prismjs/themes/prism-tomorrow.css";
import "prismjs/components/prism-javascript";
import "prismjs/components/prism-typescript";
import "prismjs/components/prism-python";
import "prismjs/components/prism-jsx";
import "prismjs/components/prism-tsx";
import "prismjs/components/prism-css";
import "prismjs/components/prism-sass";
import "prismjs/components/prism-scss";
import "prismjs/components/prism-json";
import "prismjs/components/prism-bash";
import "prismjs/components/prism-sql";
import "prismjs/components/prism-go";
import "prismjs/components/prism-csharp";
import "prismjs/components/prism-java";
import "prismjs/components/prism-rust";
import "prismjs/components/prism-markdown";
import "prismjs/components/prism-yaml";
import "prismjs/components/prism-docker";
import "prismjs/components/prism-php";
import "prismjs/components/prism-c";
import "prismjs/components/prism-cpp";

interface CodeSnippetViewProps {
  code: string;
  language?: string;
  title?: string;
  className?: string;
}

export function CodeSnippetView({ 
  code, 
  language = "javascript", 
  title, 
  className = "" 
}: CodeSnippetViewProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    Prism.highlightAll();
  }, [code, language]);
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    
    toast({
      title: "Copied to clipboard",
      description: "Code snippet has been copied to your clipboard",
    });
    
    setTimeout(() => setCopied(false), 2000);
  };
  
  const downloadCode = () => {
    const extension = getFileExtension(language);
    const blob = new Blob([code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `snippet.${extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Downloaded",
      description: `Code saved as snippet.${extension}`,
    });
  };
  
  const shareCode = () => {
    if (navigator.share) {
      navigator.share({
        title: title || "Code Snippet",
        text: code,
      }).catch(error => console.error("Error sharing:", error));
    } else {
      copyToClipboard();
    }
  };
  
  const getFileExtension = (lang: string): string => {
    const extensions: Record<string, string> = {
      javascript: "js",
      typescript: "ts",
      python: "py",
      jsx: "jsx",
      tsx: "tsx",
      css: "css",
      scss: "scss",
      sass: "sass",
      json: "json",
      bash: "sh",
      sql: "sql",
      go: "go",
      csharp: "cs",
      java: "java",
      rust: "rs",
      markdown: "md",
      yaml: "yml",
      php: "php",
      c: "c",
      cpp: "cpp",
    };
    
    return extensions[lang] || "txt";
  };
  
  return (
    <div className={`bg-zinc-900 border border-zinc-800 rounded-md ${className}`}>
      <div className="flex items-center justify-between border-b border-zinc-800 px-4 py-2">
        <div className="text-sm font-medium text-zinc-400">
          {title || language}
        </div>
        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={copyToClipboard}
                >
                  {copied ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Copy code</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={downloadCode}
                >
                  <Download className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Download code</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8" 
                  onClick={shareCode}
                >
                  <Share2 className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Share code</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
      <pre className="p-4 overflow-x-auto text-sm rounded-b-md m-0">
        <code className={`language-${language}`}>{code}</code>
      </pre>
    </div>
  );
}
