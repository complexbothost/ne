import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "./ui/command";
import { useAuth } from "@/hooks/use-auth";
import { FilePlus, Home, User, Settings, LogOut, FileText, Users, Search, Plus, Bookmark, Box, BriefcaseBusiness, LifeBuoy, Moon, Sun, Palette, ShoppingCart, Layout, Terminal } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { Button } from "./ui/button";
import { useQueryClient } from "@tanstack/react-query";

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();
  const { theme, setTheme } = useTheme();
  const queryClient = useQueryClient();

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const runCommand = (command: () => void) => {
    setOpen(false);
    command();
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      queryClient.clear();
      navigate('/auth');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <>
      <Button
        variant="outline"
        className="text-xs gap-1 border-zinc-800 bg-zinc-900/60 text-zinc-400"
        onClick={() => setOpen(true)}
      >
        <Search className="h-3 w-3" />
        <span>Search...</span>
        <kbd className="ml-2 pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-zinc-800 bg-zinc-950 px-1.5 font-mono text-[10px] font-medium opacity-100">
          <span className="text-xs">⌘</span>K
        </kbd>
      </Button>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Type a command or search..." />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>

          <CommandGroup heading="Navigation">
            <CommandItem
              onSelect={() => runCommand(() => navigate("/"))}
            >
              <Home className="mr-2 h-4 w-4" />
              <span>Home</span>
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => navigate("/search"))}
            >
              <Search className="mr-2 h-4 w-4" />
              <span>Search</span>
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => navigate("/users"))}
            >
              <Users className="mr-2 h-4 w-4" />
              <span>Browse Users</span>
            </CommandItem>
            {user && (
              <CommandItem
                onSelect={() => runCommand(() => navigate(`/user/${user.id}`))}
              >
                <User className="mr-2 h-4 w-4" />
                <span>My Profile</span>
              </CommandItem>
            )}
            <CommandItem
              onSelect={() => runCommand(() => navigate("/shop"))}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              <span>Shop</span>
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          <CommandGroup heading="Actions">
            <CommandItem
              onSelect={() => runCommand(() => navigate("/paste/new"))}
            >
              <FilePlus className="mr-2 h-4 w-4" />
              <span>New Paste</span>
            </CommandItem>
            {user && (
              <>
                <CommandItem
                  onSelect={() => runCommand(() => navigate("/settings"))}
                >
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Account Settings</span>
                </CommandItem>
                <CommandItem
                  onSelect={() => runCommand(() => navigate("/workspace"))}
                >
                  <Layout className="mr-2 h-4 w-4" />
                  <span>Workspace Settings</span>
                </CommandItem>
                <CommandItem
                  onSelect={() => runCommand(() => navigate("/user/pastes"))}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  <span>My Pastes</span>
                </CommandItem>
                <CommandItem
                  onSelect={() => runCommand(() => navigate("/user/bookmarks"))}
                >
                  <Bookmark className="mr-2 h-4 w-4" />
                  <span>My Bookmarks</span>
                </CommandItem>
              </>
            )}
          </CommandGroup>

          {user?.isAdmin && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Admin">
                <CommandItem
                  onSelect={() => runCommand(() => navigate("/admin"))}
                >
                  <BriefcaseBusiness className="mr-2 h-4 w-4" />
                  <span>Admin Dashboard</span>
                </CommandItem>
              </CommandGroup>
            </>
          )}

          <CommandSeparator />

          <CommandGroup heading="Preferences">
            <CommandItem
              onSelect={() => runCommand(() => setTheme(theme === "light" ? "dark" : "light"))}
            >
              {theme === "light" ? (
                <>
                  <Moon className="mr-2 h-4 w-4" />
                  <span>Dark Mode</span>
                </>
              ) : (
                <>
                  <Sun className="mr-2 h-4 w-4" />
                  <span>Light Mode</span>
                </>
              )}
            </CommandItem>
            <CommandItem
              onSelect={() => runCommand(() => navigate("/workspace"))}
            >
              <Terminal className="mr-2 h-4 w-4" />
              <span>Keyboard Shortcuts</span>
            </CommandItem>
          </CommandGroup>

          <CommandSeparator />

          <CommandGroup heading="Support">
            <CommandItem
              onSelect={() => runCommand(() => navigate("/help"))}
            >
              <LifeBuoy className="mr-2 h-4 w-4" />
              <span>Help & Support</span>
            </CommandItem>
          </CommandGroup>

          {user && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Account">
                <CommandItem
                  onSelect={() => runCommand(() => {
                    handleLogout();
                  })}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log Out</span>
                </CommandItem>
              </CommandGroup>
            </>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}