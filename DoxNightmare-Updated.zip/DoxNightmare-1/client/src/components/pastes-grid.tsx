import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Filter, Code, Eye, Bookmark, Calendar, Pin } from "lucide-react";
import { Link, useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";

interface Paste {
  id: number;
  title: string;
  content: string;
  createdAt: string;
  userId: number;
  username: string;
  isPrivate: boolean;
  isAdminPaste: boolean;
  isPinned: boolean;
  tags?: string[];
  views?: number;
  language?: string;
}

interface PastesGridProps {
  pastes: Paste[];
  title?: string;
  emptyMessage?: string;
  className?: string;
}

export function PastesGrid({ 
  pastes, 
  title = "Pastes", 
  emptyMessage = "No pastes found", 
  className = ""
}: PastesGridProps) {
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  
  const toggleFilter = (filter: string) => {
    if (activeFilters.includes(filter)) {
      setActiveFilters(activeFilters.filter((f) => f !== filter));
    } else {
      setActiveFilters([...activeFilters, filter]);
    }
  };
  
  const filteredPastes = pastes.filter((paste) => {
    if (activeFilters.includes("adminOnly") && !paste.isAdminPaste) {
      return false;
    }
    if (activeFilters.includes("pinnedOnly") && !paste.isPinned) {
      return false;
    }
    return true;
  });
  
  // Get paste excerpt (first 100 characters)
  const getPasteExcerpt = (content: string) => {
    return content.length > 100 ? content.substring(0, 100) + "..." : content;
  };
  
  return (
    <div className={className}>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold">{title}</h2>
        
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            className={`gap-2 ${activeFilters.includes("adminOnly") ? "bg-purple-600/20 border-purple-600" : ""}`}
            onClick={() => toggleFilter("adminOnly")}
          >
            <Code className="h-4 w-4" />
            <span>Admin Pastes</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            className={`gap-2 ${activeFilters.includes("pinnedOnly") ? "bg-purple-600/20 border-purple-600" : ""}`}
            onClick={() => toggleFilter("pinnedOnly")}
          >
            <Pin className="h-4 w-4" />
            <span>Pinned</span>
          </Button>
          
          <div className="border-l border-zinc-700 h-6 mx-1"></div>
          
          <Button
            variant={viewMode === "grid" ? "secondary" : "outline"}
            size="icon"
            className="h-9 w-9"
            onClick={() => setViewMode("grid")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
            </svg>
          </Button>
          
          <Button
            variant={viewMode === "list" ? "secondary" : "outline"}
            size="icon"
            className="h-9 w-9"
            onClick={() => setViewMode("list")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="8" y1="6" x2="21" y2="6" />
              <line x1="8" y1="12" x2="21" y2="12" />
              <line x1="8" y1="18" x2="21" y2="18" />
              <line x1="3" y1="6" x2="3.01" y2="6" />
              <line x1="3" y1="12" x2="3.01" y2="12" />
              <line x1="3" y1="18" x2="3.01" y2="18" />
            </svg>
          </Button>
        </div>
      </div>
      
      {filteredPastes.length === 0 ? (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-lg p-8 text-center">
          <Filter className="h-10 w-10 text-zinc-700 mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No pastes found</h3>
          <p className="text-zinc-400 mb-4">{emptyMessage}</p>
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPastes.map((paste) => (
            <Link to={`/paste/${paste.id}`} key={paste.id}>
              <Card className="h-full border-zinc-800 bg-zinc-900/60 transition-all hover:bg-zinc-800/60 hover:border-zinc-700">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg font-medium truncate">
                      {paste.title}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {paste.isPinned && (
                        <Badge className="bg-amber-600 text-white">
                          <Pin className="h-3 w-3 mr-1" />
                          Pinned
                        </Badge>
                      )}
                      {paste.isAdminPaste && (
                        <Badge className="bg-purple-600 text-white">
                          Admin
                        </Badge>
                      )}
                      {paste.isPrivate && (
                        <Badge variant="outline">Private</Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-zinc-400 text-sm mb-4 line-clamp-3">
                    {getPasteExcerpt(paste.content)}
                  </div>
                  {paste.tags && paste.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {paste.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="pt-2 border-t border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={`/api/users/${paste.userId}/avatar`} />
                      <AvatarFallback className="text-xs">
                        {paste.username[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-zinc-500">{paste.username}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-zinc-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDistanceToNow(new Date(paste.createdAt), { addSuffix: true })}
                    </div>
                    {paste.views !== undefined && (
                      <div className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {paste.views}
                      </div>
                    )}
                  </div>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="divide-y divide-zinc-800 border border-zinc-800 rounded-lg overflow-hidden">
          {filteredPastes.map((paste) => (
            <Link 
              to={`/paste/${paste.id}`} 
              key={paste.id}
              className="block bg-zinc-900/60 hover:bg-zinc-800/60 transition-colors"
            >
              <div className="p-4 md:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-medium truncate">{paste.title}</h3>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {paste.isPinned && (
                        <Badge className="bg-amber-600 text-white">
                          <Pin className="h-3 w-3 mr-1" />
                          Pinned
                        </Badge>
                      )}
                      {paste.isAdminPaste && (
                        <Badge className="bg-purple-600 text-white">
                          Admin
                        </Badge>
                      )}
                      {paste.isPrivate && (
                        <Badge variant="outline">Private</Badge>
                      )}
                    </div>
                  </div>
                  <p className="text-zinc-400 text-sm line-clamp-1">{getPasteExcerpt(paste.content)}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={`/api/users/${paste.userId}/avatar`} />
                      <AvatarFallback className="text-xs">
                        {paste.username[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-zinc-500">{paste.username}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-zinc-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDistanceToNow(new Date(paste.createdAt), { addSuffix: true })}
                    </div>
                    {paste.views !== undefined && (
                      <div className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {paste.views}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}