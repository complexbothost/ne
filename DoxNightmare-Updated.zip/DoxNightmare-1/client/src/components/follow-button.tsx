
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { UserPlus, UserMinus, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import axios from "axios";

interface FollowButtonProps {
  userId: number;
  initialIsFollowing: boolean;
  onFollowChange?: (isFollowing: boolean) => void;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg" | "icon";
  showText?: boolean;
}

export function FollowButton({
  userId,
  initialIsFollowing,
  onFollowChange,
  variant = "outline",
  size = "default",
  showText = true,
}: FollowButtonProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing);
  const [isLoading, setIsLoading] = useState(false);

  const handleToggleFollow = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "You need to log in to follow users",
        variant: "destructive",
      });
      return;
    }

    if (user.id === userId) {
      toast({
        title: "Action not allowed",
        description: "You cannot follow yourself",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      if (isFollowing) {
        await axios.delete(`/api/users/${userId}/follow`);
        setIsFollowing(false);
        toast({
          title: "Unfollowed",
          description: "You are no longer following this user",
        });
      } else {
        await axios.post(`/api/users/${userId}/follow`);
        setIsFollowing(true);
        toast({
          title: "Following",
          description: "You are now following this user",
        });
      }
      
      if (onFollowChange) {
        onFollowChange(!isFollowing);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update follow status",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleToggleFollow}
      disabled={isLoading || !user || user.id === userId}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : isFollowing ? (
        <UserMinus className="h-4 w-4" />
      ) : (
        <UserPlus className="h-4 w-4" />
      )}
      {showText && <span className="ml-2">{isFollowing ? "Unfollow" : "Follow"}</span>}
    </Button>
  );
}
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import axios from "axios";
import { UserPlus, UserMinus } from "lucide-react";

interface FollowButtonProps {
  userId: number;
  variant?: "default" | "secondary" | "outline";
  size?: "default" | "sm" | "xs";
}

export function FollowButton({ userId, variant = "outline", size = "default" }: FollowButtonProps) {
  const { user } = useAuth();
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Check if already following when component mounts
    if (user) {
      checkFollowStatus();
    }
  }, [user, userId]);

  const checkFollowStatus = async () => {
    try {
      const response = await axios.get(`/api/users/${userId}/followers`);
      const followers = response.data;
      
      // Check if current user is in the followers list
      setIsFollowing(followers.some((follower: any) => follower.id === user?.id));
    } catch (error) {
      console.error("Error checking follow status:", error);
    }
  };

  const handleFollow = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      if (isFollowing) {
        await axios.delete(`/api/users/${userId}/follow`);
        setIsFollowing(false);
      } else {
        await axios.post(`/api/users/${userId}/follow`);
        setIsFollowing(true);
      }
    } catch (error) {
      console.error("Error toggling follow status:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const sizeClasses = {
    default: "h-10 px-4 py-2",
    sm: "h-9 px-3",
    xs: "h-8 px-2 text-xs"
  };

  return (
    <Button
      variant={variant}
      size={size === "xs" ? "sm" : size}
      className={size === "xs" ? sizeClasses.xs : undefined}
      onClick={handleFollow}
      disabled={isLoading || !user}
    >
      {isFollowing ? (
        <>
          <UserMinus className="mr-2 h-4 w-4" />
          Unfollow
        </>
      ) : (
        <>
          <UserPlus className="mr-2 h-4 w-4" />
          Follow
        </>
      )}
    </Button>
  );
}
