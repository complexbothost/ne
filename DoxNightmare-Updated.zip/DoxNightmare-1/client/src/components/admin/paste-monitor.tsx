import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ActivePaste {
  id?: number;
  userId: number;
  username: string;
  currentContent: string;
  title: string;
  lastUpdate: Date;
}

export function PasteMonitor() {
  const [activePastes, setActivePastes] = useState<Map<number, ActivePaste>>(new Map());
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const { toast } = useToast();
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/admin`;
    const newSocket = new WebSocket(wsUrl);

    newSocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'paste_update') {
        setActivePastes(prev => {
          const updated = new Map(prev);
          updated.set(data.userId, {
            id: data.pasteId,
            userId: data.userId,
            username: data.username,
            currentContent: data.content,
            title: data.title,
            lastUpdate: new Date()
          });
          return updated;
        });

        // Show toast for new paste creation
        if (data.isNew) {
          toast({
            title: "New Paste Being Created",
            description: `${data.username} is creating a new paste: ${data.title}`,
          });
        }
      }
    };

    setSocket(socket);

    return () => {
      if (socket) socket.close();
    };
  }, []);

  // Clean up old entries
  useEffect(() => {
    const cleanup = setInterval(() => {
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      
      setActivePastes(prev => {
        const updated = new Map(prev);
        for (const [userId, paste] of updated.entries()) {
          if (paste.lastUpdate < fiveMinutesAgo) {
            updated.delete(userId);
          }
        }
        return updated;
      });
    }, 30000); // Run every 30 seconds

    return () => clearInterval(cleanup);
  }, []);

  if (!activePastes.size) {
    return (
      <Card className="border-white/10 bg-black">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Live Paste Monitor</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-white/50">No active paste creation</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-white/10 bg-black">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-medium">Live Paste Monitor</CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsMinimized(!isMinimized)}
          className="h-8 w-8"
        >
          {isMinimized ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
        </Button>
      </CardHeader>
      {!isMinimized && (
        <CardContent>
          <ScrollArea className="h-[300px]">
            <div className="space-y-4">
              {Array.from(activePastes.values()).map((paste) => (
                <div key={paste.userId} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-medium">{paste.username}</h3>
                    <span className="text-xs text-white/50">
                      {new Date(paste.lastUpdate).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="rounded bg-white/5 p-2">
                    <p className="text-xs font-medium text-white/70 mb-1">{paste.title}</p>
                    <pre className="text-xs font-mono whitespace-pre-wrap text-white/50">
                      {paste.currentContent}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      )}
    </Card>
  );
}
