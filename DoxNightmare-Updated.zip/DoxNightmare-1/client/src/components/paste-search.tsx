
import { useState, useEffect, useRef } from "react";
import { Search, X, Clock, Tag } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { useNavigate } from "react-router-dom";
import { useDebounce } from "@/hooks/use-debounce";

interface SearchResult {
  id: number;
  title: string;
  tags?: string[];
  createdAt: string;
}

export function PasteSearch() {
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const debouncedQuery = useDebounce(query, 300);
  
  useEffect(() => {
    // Load recent searches from localStorage
    const savedSearches = localStorage.getItem("recentSearches");
    if (savedSearches) {
      setRecentSearches(JSON.parse(savedSearches));
    }
    
    // Handle clicks outside the search component
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  
  useEffect(() => {
    const fetchSearchResults = async () => {
      if (!debouncedQuery.trim()) {
        setSearchResults([]);
        return;
      }
      
      setLoading(true);
      try {
        const response = await fetch(`/api/pastes/search?q=${encodeURIComponent(debouncedQuery)}`);
        const data = await response.json();
        setSearchResults(data);
      } catch (error) {
        console.error("Error searching pastes:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchSearchResults();
  }, [debouncedQuery]);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    
    // Save to recent searches
    const updatedSearches = [
      query,
      ...recentSearches.filter(s => s !== query)
    ].slice(0, 5);
    
    setRecentSearches(updatedSearches);
    localStorage.setItem("recentSearches", JSON.stringify(updatedSearches));
    
    // Navigate to search results page
    navigate(`/search?q=${encodeURIComponent(query)}`);
    setIsOpen(false);
  };
  
  const handleResultClick = (id: number) => {
    navigate(`/paste/${id}`);
    setIsOpen(false);
  };
  
  const handleRecentSearchClick = (searchTerm: string) => {
    setQuery(searchTerm);
    navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
    setIsOpen(false);
  };
  
  const clearSearch = () => {
    setQuery("");
    setSearchResults([]);
  };
  
  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem("recentSearches");
  };
  
  return (
    <div className="relative w-full md:w-64 lg:w-80" ref={searchRef}>
      <form onSubmit={handleSearch} className="relative">
        <Input
          type="search"
          placeholder="Search pastes..."
          className="pl-10 pr-10 bg-zinc-900/60 border-zinc-800 focus-visible:ring-purple-600"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
        />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
        {query && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6"
            onClick={clearSearch}
          >
            <X className="h-3 w-3" />
          </Button>
        )}
      </form>
      
      {isOpen && (
        <Card className="absolute top-full mt-1 w-full z-50 border-zinc-800 bg-zinc-900 shadow-lg">
          {loading ? (
            <div className="p-4 text-center text-sm text-zinc-400">Searching...</div>
          ) : searchResults.length > 0 ? (
            <div className="max-h-80 overflow-y-auto">
              <div className="p-2 text-xs font-medium text-zinc-500">Search Results</div>
              <div className="divide-y divide-zinc-800">
                {searchResults.map((result) => (
                  <div
                    key={result.id}
                    className="p-3 hover:bg-zinc-800/50 cursor-pointer"
                    onClick={() => handleResultClick(result.id)}
                  >
                    <div className="font-medium text-sm text-white">{result.title}</div>
                    {result.tags && result.tags.length > 0 && (
                      <div className="flex items-center gap-1 mt-1">
                        <Tag className="h-3 w-3 text-zinc-500" />
                        <div className="text-xs text-zinc-400">
                          {result.tags.join(", ")}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div>
              {query && (
                <div className="p-4 text-center text-sm text-zinc-400">
                  No results found for "{query}"
                </div>
              )}
              
              {recentSearches.length > 0 && (
                <div>
                  <div className="flex items-center justify-between p-2 text-xs font-medium text-zinc-500">
                    <span>Recent Searches</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 text-xs"
                      onClick={clearRecentSearches}
                    >
                      Clear All
                    </Button>
                  </div>
                  <div className="divide-y divide-zinc-800">
                    {recentSearches.map((term, index) => (
                      <div
                        key={index}
                        className="p-3 hover:bg-zinc-800/50 cursor-pointer flex items-center"
                        onClick={() => handleRecentSearchClick(term)}
                      >
                        <Clock className="h-3 w-3 text-zinc-500 mr-2" />
                        <span className="text-sm text-zinc-400">{term}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
