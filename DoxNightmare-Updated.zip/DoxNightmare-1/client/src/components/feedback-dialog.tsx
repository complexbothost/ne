import { useState } from "react";
import { MessageCircleQuestion, X, Send } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "./ui/dialog";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Label } from "./ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/utils/api";


export function FeedbackDialog() {
  const [open, setOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState<"bug" | "suggestion" | "general">("general");
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!message.trim()) {
      toast({
        title: "Empty message",
        description: "Please enter your feedback before submitting",
        variant: "destructive"
      });
      return;
    }

    setIsSending(true);

    try {
      await apiRequest("POST", "/api/feedback", {
        type: feedbackType,
        message,
        userId: user?.id
      });

      toast({
        title: "Feedback sent",
        description: "Thank you for your feedback!",
      });

      setMessage("");
      setFeedbackType("general");
      setOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send feedback. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="gap-2 h-8 fixed bottom-4 right-4 z-10 bg-zinc-900 border-zinc-800"
        >
          <MessageCircleQuestion className="h-4 w-4 text-purple-400" />
          <span>Feedback</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md border-zinc-800 bg-zinc-900">
        <DialogHeader>
          <DialogTitle>Send Feedback</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="flex items-center gap-2 mb-4">
            <Avatar className="h-8 w-8">
              {user && user.avatarUrl ? (
                <AvatarImage src={user.avatarUrl} />
              ) : (
                <AvatarFallback>
                  {user ? user.username[0].toUpperCase() : "?"}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="text-sm">
              <p className="font-medium">
                {user ? user.username : "Anonymous User"}
              </p>
              <p className="text-zinc-400 text-xs">
                {user ? "Signed in user" : "Not signed in"}
              </p>
            </div>
          </div>

          <div className="mb-4">
            <Label className="text-sm mb-2 block">Feedback Type</Label>
            <RadioGroup
              value={feedbackType}
              onValueChange={(value) => setFeedbackType(value as "bug" | "suggestion" | "general")}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bug" id="bug" />
                <Label htmlFor="bug">Bug Report</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="suggestion" id="suggestion" />
                <Label htmlFor="suggestion">Suggestion</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="general" id="general" />
                <Label htmlFor="general">General</Label>
              </div>
            </RadioGroup>
          </div>

          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Describe your feedback in detail..."
            rows={5}
            className="bg-zinc-950 border-zinc-800 mb-4"
          />

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="gap-2"
            >
              <X className="h-4 w-4" />
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="gap-2 bg-purple-600 hover:bg-purple-700"
              disabled={isSending}
            >
              <Send className="h-4 w-4" />
              {isSending ? "Sending..." : "Send Feedback"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}