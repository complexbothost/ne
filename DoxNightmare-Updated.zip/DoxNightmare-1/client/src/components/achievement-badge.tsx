
import { AchievementType } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Medal, Star, Users, FileText, UserCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface AchievementBadgeProps {
  type: AchievementType;
  size?: "sm" | "md" | "lg";
  className?: string;
  withTooltip?: boolean;
}

const achievementData: Record<AchievementType, { title: string; description: string; icon: React.ReactNode; color: string }> = {
  first_paste: {
    title: "First Paste",
    description: "Created your first paste",
    icon: <FileText className="h-full w-full" />,
    color: "text-blue-400 bg-blue-500/20"
  },
  popular_paste: {
    title: "Popular Content",
    description: "Created a paste that got high visibility",
    icon: <Star className="h-full w-full" />,
    color: "text-yellow-400 bg-yellow-500/20"
  },
  contributor: {
    title: "Contributor",
    description: "Regular contributor to the platform",
    icon: <Medal className="h-full w-full" />,
    color: "text-purple-400 bg-purple-500/20"
  },
  community_member: {
    title: "Community Member",
    description: "Active in the community with comments and interactions",
    icon: <Users className="h-full w-full" />,
    color: "text-green-400 bg-green-500/20"
  },
  profile_complete: {
    title: "Profile Complete",
    description: "Completed your user profile with all information",
    icon: <UserCircle className="h-full w-full" />,
    color: "text-indigo-400 bg-indigo-500/20"
  }
};

export function AchievementBadge({ type, size = "md", className, withTooltip = true }: AchievementBadgeProps) {
  const { title, description, icon, color } = achievementData[type];

  const sizeClasses = {
    sm: "h-6 w-6 p-1",
    md: "h-8 w-8 p-1.5",
    lg: "h-12 w-12 p-2"
  };

  const badge = (
    <div className={cn(
      "rounded-full flex items-center justify-center border",
      color,
      sizeClasses[size],
      className
    )}>
      {icon}
    </div>
  );

  if (!withTooltip) {
    return badge;
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {badge}
        </TooltipTrigger>
        <TooltipContent side="top">
          <div className="text-center">
            <p className="font-semibold">{title}</p>
            <p className="text-xs text-muted-foreground">{description}</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
import { AchievementType } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Medal, Star, Users, FileText, UserCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface AchievementBadgeProps {
  type: AchievementType;
  size?: "default" | "sm" | "lg";
  withTooltip?: boolean;
}

export function AchievementBadge({ 
  type, 
  size = "default", 
  withTooltip = true 
}: AchievementBadgeProps) {
  const achievementConfig: Record<AchievementType, {
    title: string;
    description: string;
    icon: React.ReactNode;
    color: string;
  }> = {
    "first_paste": {
      title: "First Paste",
      description: "Created your first paste",
      icon: <FileText className="h-full w-full" />,
      color: "bg-blue-500"
    },
    "popular_paste": {
      title: "Popular Content",
      description: "Created content with high visibility",
      icon: <Star className="h-full w-full" />,
      color: "bg-yellow-500"
    },
    "contributor": {
      title: "Contributor",
      description: "Created 10+ pastes",
      icon: <Medal className="h-full w-full" />,
      color: "bg-purple-500"
    },
    "community_member": {
      title: "Community Member",
      description: "Left 5+ comments",
      icon: <Users className="h-full w-full" />,
      color: "bg-green-500"
    },
    "profile_complete": {
      title: "Profile Complete",
      description: "Completed your profile information",
      icon: <UserCircle className="h-full w-full" />,
      color: "bg-red-500"
    }
  };

  const { title, description, icon, color } = achievementConfig[type];

  const sizeClasses = {
    sm: "h-6 w-6",
    default: "h-8 w-8",
    lg: "h-12 w-12"
  };

  const badge = (
    <div className={cn(
      "relative flex items-center justify-center text-white rounded-full",
      color,
      sizeClasses[size]
    )}>
      {icon}
    </div>
  );

  if (withTooltip) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {badge}
          </TooltipTrigger>
          <TooltipContent>
            <div>
              <p className="font-semibold">{title}</p>
              <p className="text-xs text-muted-foreground">{description}</p>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return badge;
}
