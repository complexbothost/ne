
import { useState, useEffect } from "react";
import { Bell, X, CheckCheck, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { useAuth } from "@/hooks/use-auth";

interface Notification {
  id: number;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  type: 'admin' | 'system' | 'user';
}

export function NotificationsDrawer() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { user } = useAuth();
  
  // Mock notifications for demonstration
  useEffect(() => {
    if (user) {
      const mockNotifications: Notification[] = [
        {
          id: 1,
          title: "Welcome to Pastebin",
          message: "Thanks for joining our community! We hope you enjoy sharing your pastes securely.",
          read: false,
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          type: 'system'
        },
        {
          id: 2,
          title: "New Admin Announcement",
          message: "We've updated our Terms of Service. Please review the changes.",
          read: true,
          createdAt: new Date(Date.now() - 86400000).toISOString(),
          type: 'admin'
        },
        {
          id: 3,
          title: "Your paste is trending",
          message: "Your paste 'JavaScript Tips & Tricks' is gaining popularity!",
          read: false,
          createdAt: new Date(Date.now() - 172800000).toISOString(),
          type: 'user'
        }
      ];
      
      setNotifications(mockNotifications);
      setUnreadCount(mockNotifications.filter(n => !n.read).length);
    }
  }, [user]);
  
  const markAllAsRead = () => {
    setNotifications(notifications.map(notification => ({
      ...notification,
      read: true
    })));
    setUnreadCount(0);
  };
  
  const markAsRead = (id: number) => {
    setNotifications(notifications.map(notification => 
      notification.id === id ? { ...notification, read: true } : notification
    ));
    setUnreadCount(prev => Math.max(0, prev - 1));
  };
  
  const deleteNotification = (id: number) => {
    const notificationToDelete = notifications.find(n => n.id === id);
    setNotifications(notifications.filter(notification => notification.id !== id));
    if (notificationToDelete && !notificationToDelete.read) {
      setUnreadCount(prev => Math.max(0, prev - 1));
    }
  };
  
  return (
    <div>
      <Button
        variant="ghost"
        size="icon"
        className="relative"
        onClick={() => setOpen(!open)}
        aria-label="Open notifications"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center w-4 h-4 text-xs font-bold text-white bg-red-500 rounded-full">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </Button>
      
      {open && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <Card className="w-80 md:w-96 h-full rounded-none border-l border-r-0 border-t-0 border-b-0 border-zinc-800 bg-zinc-900 flex flex-col z-50">
            <div className="p-4 border-b border-zinc-800 flex justify-between items-center">
              <h2 className="font-semibold text-lg">Notifications</h2>
              <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            {notifications.length > 0 ? (
              <>
                <div className="p-2 border-b border-zinc-800 flex justify-between items-center">
                  <span className="text-sm text-zinc-400">
                    {unreadCount === 0 ? "All caught up!" : `${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`}
                  </span>
                  {unreadCount > 0 && (
                    <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs h-8">
                      <CheckCheck className="h-3 w-3 mr-1" />
                      Mark all as read
                    </Button>
                  )}
                </div>
                
                <ScrollArea className="flex-1 overflow-auto">
                  <div className="divide-y divide-zinc-800">
                    {notifications.map((notification) => (
                      <div 
                        key={notification.id} 
                        className={`p-4 ${notification.read ? 'bg-transparent' : 'bg-zinc-800/20'}`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <h3 className="font-medium text-sm">
                            {notification.title}
                          </h3>
                          <div className="flex items-center gap-1">
                            {!notification.read && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6" 
                                onClick={() => markAsRead(notification.id)}
                              >
                                <CheckCheck className="h-3 w-3" />
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6 text-red-400" 
                              onClick={() => deleteNotification(notification.id)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-xs text-zinc-400 mb-2">{notification.message}</p>
                        <div className="text-xs text-zinc-500">
                          {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-4 text-center">
                <Bell className="h-12 w-12 text-zinc-700 mb-2" />
                <h3 className="font-medium mb-1">No notifications</h3>
                <p className="text-sm text-zinc-500">When you receive notifications, they'll appear here</p>
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
