
import { useState, useRef, KeyboardEvent } from "react";
import { X, Tag as TagIcon } from "lucide-react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface TagInputProps {
  tags: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
  maxTags?: number;
  className?: string;
}

export function TagInput({
  tags,
  onChange,
  placeholder = "Add tags...",
  maxTags = 10,
  className = "",
}: TagInputProps) {
  const [inputValue, setInputValue] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };
  
  const addTag = (tag: string) => {
    // Skip if empty, over max length, or already exists
    if (
      !tag.trim() ||
      tags.length >= maxTags ||
      tags.includes(tag.trim())
    ) {
      return;
    }
    
    const newTags = [...tags, tag.trim()];
    onChange(newTags);
    setInputValue("");
  };
  
  const removeTag = (tagToRemove: string) => {
    const newTags = tags.filter((tag) => tag !== tagToRemove);
    onChange(newTags);
  };
  
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(inputValue);
    } else if (e.key === "Backspace" && !inputValue && tags.length > 0) {
      // Remove the last tag when backspace is pressed on empty input
      const newTags = [...tags];
      newTags.pop();
      onChange(newTags);
    }
  };
  
  const handleContainerClick = () => {
    inputRef.current?.focus();
  };
  
  return (
    <div
      className={`flex flex-wrap items-center gap-2 p-2 border border-zinc-800 bg-zinc-900/60 rounded-md focus-within:ring-1 focus-within:ring-purple-600 ${className}`}
      onClick={handleContainerClick}
    >
      {tags.map((tag) => (
        <div
          key={tag}
          className="flex items-center gap-1 bg-zinc-800 text-white text-sm rounded-md px-2 py-1"
        >
          <TagIcon className="h-3 w-3 text-purple-400" />
          <span>{tag}</span>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-4 w-4 hover:bg-zinc-700"
            onClick={() => removeTag(tag)}
          >
            <X className="h-2 w-2" />
          </Button>
        </div>
      ))}
      <Input
        ref={inputRef}
        type="text"
        value={inputValue}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        placeholder={tags.length < maxTags ? placeholder : `Maximum ${maxTags} tags`}
        className="flex-1 min-w-[120px] border-0 bg-transparent p-0 text-sm focus-visible:ring-0 focus-visible:ring-offset-0"
        disabled={tags.length >= maxTags}
      />
    </div>
  );
}
