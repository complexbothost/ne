import { useState, useEffect } from "react";
import { insertPasteSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";
import { useLocation, Link } from "wouter";
import { Upload } from "lucide-react";
import { debounce } from "lodash";
import { useToast } from "@/hooks/use-toast";

interface PasteFormProps {
  onSuccess?: () => void;
  skipRedirect?: boolean;
}

type FormValues = z.infer<typeof insertPasteSchema>;

export default function PasteForm({ onSuccess, skipRedirect }: PasteFormProps) {
  const { user } = useAuth();
  const isAdmin = user?.isAdmin;
  const [_, navigate] = useLocation();
  const [fileError, setFileError] = useState<string | null>(null);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!user) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const newSocket = new WebSocket(wsUrl);

    newSocket.onopen = () => {
      newSocket.send(JSON.stringify({
        type: 'auth',
        userId: user.id
      }));
    };

    setSocket(newSocket);

    return () => {
      if (newSocket) newSocket.close();
    };
  }, [user]);

  // Send updates to admins
  const sendUpdate = debounce((content: string, title: string) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'paste_update',
        content,
        title,
        userId: user?.id
      }));
    }
  }, 500);

  const form = useForm<FormValues>({
    resolver: zodResolver(insertPasteSchema),
    defaultValues: {
      title: "",
      content: "",
      isPrivate: false,
      isHidden: false,
      isAdminPaste: false,
      isPinned: false,
      extraDetails: "",
    },
  });

  // Monitor changes for admin viewing
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === 'content' || name === 'title') {
        sendUpdate(form.getValues('content'), form.getValues('title'));
      }
    });
    return () => subscription.unsubscribe();
  }, [form.watch, socket]);

  const createPasteMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const pasteData = { ...data };
      try {
        const res = await apiRequest("POST", "/api/pastes", pasteData);
        const result = await res.json();

        if (result.error === 'RATE_LIMIT_EXCEEDED') {
          throw new Error('Please wait a minute before creating another paste.');
        }

        if (result.duplicate) {
          toast({
            title: "Duplicate Content Detected",
            description: (
              <div>
                This content already exists in another paste.{" "}
                <Link href={`/paste/${result.duplicate.id}`}>View existing paste</Link>
              </div>
            ),
          });
          return result.duplicate;
        }

        return result;
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(error.message);
        }
        throw new Error('Failed to create paste');
      }
    },
    onSuccess: (data) => {
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/pastes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/pastes"] });
      if (onSuccess) {
        onSuccess();
      } else if (!skipRedirect) {
        navigate(`/paste/${data.id}`);
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.name.endsWith('.txt') && !file.name.endsWith('.csv')) {
      setFileError('Only .txt and .csv files are allowed');
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setFileError('File size must be less than 5MB');
      return;
    }

    setFileError(null);

    try {
      const content = await file.text();
      form.setValue('content', content);
      form.setValue('title', file.name.split('.')[0]); // Set title to filename without extension
    } catch (error) {
      setFileError('Error reading file');
    }
  };

  const onSubmit = (data: FormValues) => {
    if (isAdmin) {
      createPasteMutation.mutate(data);
    } else {
      const { isAdminPaste, isPinned, extraDetails, isHidden, ...regularData } = data;
      createPasteMutation.mutate(regularData as FormValues);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-2">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem className="space-y-0.5">
              <FormLabel className="text-xs">Title</FormLabel>
              <FormControl>
                <Input placeholder="Enter title" className="h-7 text-sm" {...field} />
              </FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        <div className="space-y-2">
          <FormLabel className="text-sm">Content</FormLabel>
          <div className="flex items-center gap-2">
            <Input
              type="file"
              accept=".txt,.csv"
              onChange={handleFileUpload}
              className="flex-1 h-8 text-sm"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="border-white/10 text-white/70 hover:bg-white/5"
              onClick={() => document.querySelector<HTMLInputElement>('input[type="file"]')?.click()}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload File
            </Button>
          </div>
          {fileError && (
            <p className="text-xs text-red-400">{fileError}</p>
          )}
        </div>

        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem className="space-y-1">
              <FormControl>
                <Textarea
                  placeholder="Enter content or upload a file..."
                  className="min-h-[100px] resize-none text-sm"
                  {...field}
                />
              </FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )}
        />

        

        {isAdmin && (
          <>
            <Separator className="my-2" />
            <div className="p-2 border rounded-lg border-white/20 bg-zinc-900 space-y-2">
              <h3 className="text-xs font-medium">Admin Options</h3>

              <FormField
                control={form.control}
                name="isAdminPaste"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between space-y-0">
                    <div>
                      <FormLabel className="text-sm">Admin Paste</FormLabel>
                      <FormDescription className="text-xs">
                        Rainbow highlight & 2x size
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isPinned"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between space-y-0">
                    <div>
                      <FormLabel className="text-sm">Pin to Top</FormLabel>
                      <FormDescription className="text-xs">
                        Pin for 24 hours
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="extraDetails"
                render={({ field }) => (
                  <FormItem className="space-y-1">
                    <FormLabel className="text-sm">Extra Details</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add admin note..."
                        className="min-h-[60px] resize-none text-sm"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage className="text-xs" />
                  </FormItem>
                )}
              />
            </div>
          </>
        )}

        <Button
          type="submit"
          className="w-full h-8 text-sm"
          disabled={createPasteMutation.isPending}
        >
          {createPasteMutation.isPending ? "Creating..." : "Create Paste"}
        </Button>
      </form>
    </Form>
  );
}