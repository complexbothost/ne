import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { HomePage } from "./pages/home-page";
import { AboutPage } from "./pages/about-page";
import { ContactPage } from "./pages/contact-page";
import { TOSPage } from "./pages/tos-page";
import { SuggestionsPage } from "./pages/suggestions-page";
import { GangFeaturesPage } from "./pages/gang-features-page";
import { ShopPage } from "./pages/shop-page";
import { LoginPage } from "./pages/login-page";
import AchievementsPage from "./pages/achievements-page";
import FollowingPage from "./pages/following-page";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/tos" element={<TOSPage />} />
        <Route path="/suggestions" element={<SuggestionsPage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/gang-features" element={<GangFeaturesPage />} />
        <Route path="/achievements" element={<AchievementsPage />} />
        <Route path="/user/:userId/follows/:tab" element={<FollowingPage />} />
        <Route path="/user/:userId/follows" element={<FollowingPage />} />
        <Route path="/login" element={<LoginPage />} />
      </Routes>
    </Router>
  );
}

export default App;